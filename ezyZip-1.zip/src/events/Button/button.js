const { } = require("discord.js");

module.exports = {
    name:"interactionCreate", // Nome do Evento 
    run: async( interaction, client) => {
        if(interaction.isButton() && interaction.customId === "feliz") { // verificando se é a interação é um botão e se o customId do botão seja "feliz"
            // Aqui será caso o seja

            interaction.reply({
                content:`Olá ${interaction.user}, Espero que seja Feliz :)`,
                ephemeral:true
            });

        }
    }
}